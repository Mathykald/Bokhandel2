<!DOCTYPE html>
<html>
<head>
	<title>Massage bokningssida </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">	
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</head>
<body>


<footer id="footer" class="page-footer font-small blue pt-4 footercolor">

  
  <div class="container-fluid text-center text-md-left ">

   
    <div class="row">

      <div class="col-md-6 mt-md-0 mt-3">

        <h5 class="text-uppercase">Footer Content</h5>
        <p>Here you can use rows and columns to organize your footer content.</p>

      </div>

      <hr class="clearfix w-100 d-md-none pb-3">

      <div class="col-md-3 mb-md-0 mb-3">

        <h5 class="text-uppercase">Sociala medier</h5>

        <ul class="list-unstyled">
          <li>
            
          </li><br>
          <p>Twitter: a</p>
          <li>
            
          </li>
          <p>Instagram: a</p>
          <li>
            
          </li>
          <p>Facebook: a</p>
          <li>
            
          </li>
        </ul>

      </div>
      

      
      <div class="col-md-3 mb-md-0 mb-3">

       
        <h5 class="text-uppercase">Kontaktinformation</h5>

        <ul class="list-unstyled">
          <li>
            
          </li><br>
          <p>Telefonnummer: 0417498531</p>
          <li>

          </li>
          <p>Gmail: a.a@a.com</p>
          <li>
            
          </li>
        </ul>

      </div>
      

    </div>
    

  </div>
  

  
  <div class="colorblack footer-copyright text-center py-3">© 2020 Copyright:
    <p class="colorblack">Matheus</p>
  </div>
 

</footer>



</body>
</html>