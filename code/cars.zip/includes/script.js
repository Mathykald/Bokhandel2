
function submitSortForm(){
	document.getElementById('sortform').submit();
	}
	
	function submitFilterForm(){
		    document.getElementById('sortform').submit();
	}

